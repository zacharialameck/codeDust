//try changing the numbers on the "createcanavas" //and "backgroup" line can you figure out what they //do?

//on the createcanvas when changing the first //number,for example putting 200 it display like //a rectangle, then the second number when //changing 100 it will  display a rectangle in //parallel

function setup() {
  createCanvas(400,400);
}
//when you are adding numbers the color of the //shape will changed
//then adding the shape on background we can put //rect then changing numbers the shape will //change the position.

function draw() {
  background(220,0,100);
  rect(200,200,150)
  
  
}